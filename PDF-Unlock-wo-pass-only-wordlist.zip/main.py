    #    PDF Password Cracked Code 
# Open PDF file without password using python.
import pikepdf
import time
from colorama import Fore

password_file = open("wordlist.txt") # enter your word list name?

i = 0
start_time = time.time()
for password in password_file:
    i += 1
    print(Fore.RED+f"\r {i} Password is tested {password.strip()}", end = "")
    try:
        pikepdf.open("test.pdf",password = password.strip("\n"))
        end_time = time.time() # upr vali test  pe aap ki pdf name past ?
        print("\n")
        print(Fore.GREEN+ f"password found in {str(end_time-start_time)[:4]
        } second \nPassword is: ", end = "")
        print(Fore.BLUE+ f" {password}")


        break
    except:
        pass

    # Note:  use vs code  and  run code 
    # Code Owner Name :- Prahalad hacker
    ## Installation

#  Install package with pip

# ```bash
#   pip install pikepdf
#   pip install colorama

# ```
    
## Deployment

# To deploy this project run

# ```bash
    